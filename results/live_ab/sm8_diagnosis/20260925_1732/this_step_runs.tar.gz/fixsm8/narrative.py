"""The superseding SM8 diagnosis receipt: its text, with every count computed from the files."""
import collections
import json
import subprocess
import time

import gather as G
from archive_lib import sha256_file

SM8, CTRL = G.SM8, G.CTRL
FX = 'test_the_pre_fix_scenario_forced_never_reaches_the_restart_check'
FY = 'test_the_fixed_scenario_forced_refuses_the_restart'
OLD_REL = 'results/live_ab/SM8_DIAGNOSIS_20260925_1503.json'


def _count(rows, key):
    c = collections.Counter(r['verdicts'].get(key, 'not_run') for r in rows)
    if set(c) == {'not_run'}:
        return 'not run'
    return ', '.join('%s %d' % (k, v) for k, v in sorted(c.items())) + ' of %d' % len(rows)


def _assertions(rows):
    c = collections.Counter()
    for r in rows:
        for ln in r['failure_lines']:
            if ln.startswith('AssertionError') or ln.strip().startswith('self.assert'):
                c[ln.strip()[:200]] += 1
    return dict(c)


def step_summary(step: dict) -> dict:
    out = {}
    for label, d in step.items():
        rows = d['attempts']
        out[label] = {'attempts': len(rows), 'sm8': _count(rows, SM8),
                      'control': _count(rows, CTRL), 'forced_pre_fix_scenario': _count(rows, FX),
                      'forced_fixed_scenario': _count(rows, FY),
                      'exit_codes': dict(collections.Counter(r['exit_code'] for r in rows)),
                      'assertion_lines': _assertions(rows),
                      'loadavg_1min_before': [r['loadavg_before'][0] for r in rows],
                      'soft_gate_clean_before': [r['soft_gate_clean_before'] for r in rows],
                      'tree_head': d['tree_head'], 'tree_porcelain': d['tree_porcelain'],
                      'files_sha256': d['files_sha256']}
    return out


def suite_rows(step: dict, label: str) -> list:
    """The integrated runs of this step, from each attempt's stdout (the -v unittest output)."""
    import re
    rows = []
    d = step.get(label)
    if not d:
        return rows
    for a in d['attempts']:
        p = G.F / 'runs' / label / 'loop' / ('attempt_%02d' % a['index']) / 'stdout.log'
        text = p.read_text('utf-8', 'replace')
        rows.append({'index': a['index'], 'start_utc': a['start_utc'], 'end_utc': a['end_utc'],
                     'exit_code': a['exit_code'], 'loadavg_1min_before': a['loadavg_before'][0],
                     'soft_gate_clean_before': a['soft_gate_clean_before'],
                     'stdout_sha256': a['stdout_sha256'], 'result': G.ran_line(text),
                     'failures': G.failure_headers(text),
                     'sm8_lines': [ln for ln in text.splitlines()
                                   if re.match(r'^test_(sm8_a_library|control_the_same_crash_'
                                               r'without_the_change|the_pre_fix_scenario_forced|'
                                               r'the_fixed_scenario_forced)', ln)]})
    return rows


def signatures(label: str) -> list:
    """sm8_attempts.timeline's derived facts of every preserved tree of one run label."""
    import glob
    import sys
    sys.path.insert(0, str(G.W / 'experiments' / 'live_ab_controls'))
    import sm8_attempts
    out = []
    for tr in sorted(glob.glob(str(G.F / 'runs' / label / 'loop' / 'attempt_*' / 'trees' / '*'))):
        if tr.endswith('.json') or tr.endswith('_leftover'):
            continue
        tl = sm8_attempts.timeline(tr)
        out.append({'tree': tr.split('/loop/')[1], 'entry_returncode': tl['returncode'],
                    'server_stopped_returncodes': [e.get('returncode') for e in tl['events']
                                                   if e['type'] == 'server_stopped'],
                    **tl['derived']})
    return out


def git_head_files(commit: str) -> dict:
    out = {}
    for rel in ('experiments/live_ab_controls/tests_sm_entry.py',
                'experiments/live_ab_controls/sm8_attempts.py',
                'experiments/live_ab_controls/eb1c_llama_shim.py',
                'experiments/live_ab_controls/sm_fixture.py',
                'experiments/live_ab_controls/tests_eb1_entry.py'):
        out[rel] = G.blob_sha(commit, rel)
    return out


def receipt(*, stamp, now, fix_commit, facts, archives, manifest_rel) -> dict:
    integ, solo = facts['integrated'], facts['solo']
    step = step_summary(facts['step_runs'])
    review = facts['review_runs']
    red_i = [r['run'] for r in integ if r['sm8'] == 'RED']
    red_s = [r['run'] for r in solo if r['sm8'] == 'RED']
    old = json.loads((G.W / OLD_REL).read_text('utf-8'))
    pre_loop = [a for a in old['attempts'] if a['phase'] == 'pre_fix']
    pre_loop_red = [a['index'] for a in pre_loop if a['sm8_mode'] == 'exit_0_not_1']
    pre_loop_gate = [a['index'] for a in pre_loop if a['sm8_mode'] == 'host_not_quiescent']
    review_pre = review['pre']
    review_pre_red = sum(1 for s in review_pre['by_tag_and_verdicts'] if 'mode=exit_0_not_1' in s)
    n_solo_attempts = len(solo) + len(pre_loop) + review_pre['rows']
    n_solo_red = len(red_s) + len(pre_loop_red) + review_pre_red
    fix_files = git_head_files(fix_commit)
    pre_pins = {'experiments/live_ab_controls/' + k: v for k, v in G.PRE_PINS.items()}

    def st(label, key):
        return step.get(label, {}).get(key)

    def control_mode(att) -> str:
        text = (G.DIAG / G.LABEL_DIR[att['label']] / ('attempt_%02d' % att['index']) /
                'stdout.log').read_text('utf-8', 'replace')
        block = next((b for b in text.split('=' * 70) if ('FAIL: %s ' % CTRL) in b
                      or ('ERROR: %s ' % CTRL) in b), '')
        return 'host-gate refusal' if 'host_not_quiescent' in block else 'other'

    r = {
        'schema': 'live_ab/sm8_diagnosis-v2',
        'convention': 'deterministic-path',
        'generated_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(now)),
        'what_this_is': (
            'The answer to the adversarial review of the SM8 diagnosis (receipt ' + OLD_REL +
            ', commit 8a84153; fix 292a8a9): every finding was reproduced first (all nine '
            'reproduced), and each is corrected here or in the test fix commit ' + fix_commit +
            ', except finding 2, whose post-fix integrated run is OWED and comes from receipt '
            'R\'s run at the final head (root 16:15). This receipt SUPERSEDES the 1503 '
            'receipt for the statements listed under '
            'supersedes.corrected; the 1503 receipt stays in the repository unchanged '
            '(write-once) and its attempt records, preserved artifacts and cause stand.'),
        'authority': (
            "root, reviews/eb1_eb5_v4_interim_20260925_1315.md (origin/main), ranked request (1) "
            "preserve every red and green SM8 attempt, (2) a bounded targeted control on a "
            "quiescent host, (3) reconcile the red control before receipt R; and the session's "
            "adversarial review of the SM8 diagnosis (2026-09-25, nine findings, reproduced "
            "below). Model-free: no model, no llama-server, no build, no network beyond "
            "127.0.0.1 (lab_mock_server behind the compiled sm_fixture test double)."),
        'supersedes': {
            'path': OLD_REL, 'sha256': sha256_file(G.W / OLD_REL), 'commit': '8a84153',
            'stands_unchanged': [
                'attempts[] (71 records) and attempt_summary: every stdout digest matches the '
                'archived stdout (see archives)',
                'preserved_artifacts (29 files; the review recomputed all 29)',
                'candidate_mechanisms_written_before_running, cause.statement and cause.kind '
                '(test defect, no production defect demonstrated)',
                'fix.commit 292a8a9 and its forced interleavings',
                'observation_for_root_not_changed (carried over below, unchanged)'],
            'corrected': [
                'earlier_runs and cause.rate_observed: incomplete (finding 1) -> '
                'integrated_runs_on_the_pre_fix_sm8_bytes, solo_runs_on_the_pre_fix_sm8_bytes, '
                'rates',
                'first_divergent_event.event: misworded (finding 4) -> first_divergent_event',
                'pins.pre_fix_bytes_identical_at "last changed at 5ae183d" and the single '
                'tests_eb1_entry pin (finding 7) -> pins',
                'fix.controls[0] as the proof of the cause on pre-fix code (finding 5) -> '
                'cause_reproduced_on_the_pre_fix_shim',
                'attempts 201-204 and forced_dev 1: their load was recorded but they were not '
                'flagged as run on a non-quiescent host (finding 9) -> '
                'attempts_run_on_a_non_quiescent_host',
                'what_this_does_not_establish[3] "full suites not run at the fix" (finding 2) '
                '-> post_fix_integrated_run: still OWED, to come from receipt R\'s run']},
        'review_findings': [],
    }

    # ---------------------------------------------------------------- finding 1
    r['integrated_runs_on_the_pre_fix_sm8_bytes'] = {
        'scope': ('every live_ab_controls full-suite run from 03fe0ca (2026-09-24T15:44:23Z, '
                  'where sm_fixture.py last changed) to the diagnosis: tests_sm_entry.py, '
                  'eb1c_llama_shim.py and sm_fixture.py are byte-identical (the pre-fix pins '
                  'below) at every commit 03fe0ca..90219f2. Found by listing every unittest '
                  'log in the session work area modified after 2026-09-24T15:00Z and every '
                  'suite run recorded in a committed pin receipt. A run is counted on the '
                  'commits before and after it; for worktree runs the SM8 files at run time '
                  'were not hashed, but no commit in the range changes them and the v4 '
                  'summaries record a porcelain that names none of them.'),
        'excluded': ('subsetfix r1 (393 tests, 2026-09-24T15:25Z, SM8 not among its two '
                     'failures): it ran before 03fe0ca was committed, so its sm_fixture bytes '
                     'are not established'),
        'runs': integ,
        'counted_by_the_1503_receipt': [r0['run'] for r0 in integ if r0['in_1503_count']],
        'sm8_red': red_i,
        'sm8_red_count': '%d of %d' % (len(red_i), len(integ))}
    r['solo_runs_on_the_pre_fix_sm8_bytes'] = {
        'earlier_solo_runs': solo,
        'diagnosis_loop': ('the 1503 receipt attempts[] phase pre_fix: %d attempts, SM8 red '
                           'of the diagnosed kind in %s, SM8 lost to a host-gate refusal in %s'
                           % (len(pre_loop), pre_loop_red, pre_loop_gate)),
        'the_reviews_runs': {k: {kk: vv for kk, vv in v.items()} for k, v in review.items()},
        'the_reviews_runs_note': ('the review ran these in its own clones; their ledgers are in '
                                  'earlier_runs_logs.tar.gz under review_runs/; their rows give '
                                  'the counts the review reported')}
    r['rates'] = {
        'integrated_pre_fix': '%d red of %d full-suite runs (%s)' % (len(red_i), len(integ),
                                                                      ', '.join(red_i)),
        'solo_pre_fix': ('%d red of %d solo SM8AtTheRestart attempts: earlier %d of %d, the '
                         'diagnosis loop %d of %d (%d of those lost SM8 to a host-gate refusal, '
                         'no verdict), the review %d of %d'
                         % (n_solo_red, n_solo_attempts, len(red_s), len(solo),
                            len(pre_loop_red), len(pre_loop), len(pre_loop_gate),
                            review_pre_red, review_pre['rows'])),
        'what_the_1503_receipt_said': old['cause']['rate_observed'],
        'why_integrated_runs_are_redder': (
            'NOT established. The counts are consistent with a timing window that is wider '
            'under the integrated suite: the pre-fix red needs both calls answered in the '
            'window between the second response being written and os._exit, and in SM8 that '
            'window holds the flip (read, hash, rewrite and re-read of the 33,448 B '
            'libeb1c-core.0.dylib); see pre_fix_control_shared_the_race. That is a hypothesis; '
            'it was not measured.')}
    r['review_findings'].append({
        'id': 1, 'severity': 'medium',
        'claim': ('green integrated runs on the byte-identical SM8 files are missing from '
                  'earlier_runs; "3 of 4 integrated" is wrong'),
        'reproduced': True,
        'reproduction': (
            'All five logs the review named exist with the digests it gave (v3 base 19ba691b, '
            'v3 after aa106cb5, final_fix full_controls1 43391800, repro run15 b9eef8cd, repro '
            'run25 6fca143b), each green for SM8. Listing every log and pin receipt found five '
            'more the review did not name: eb1_1905 run2 (426 OK, 56f9701e), the suite runs '
            'of the pin receipts 1635, 1732 and 0027 (their unittest output is in the committed '
            'receipts only as a digest and tail; the 1503 receipt named 1732 and 0027 but did '
            'not count their runs), and a clean-clone full_controls run at 8f0b4ae found only by '
            'this step\'s own independent provenance check, not by the original review or by '
            'this receipt\'s first draft (repair/review_tmp/final/logs/'
            'combined_live_ab_controls.log, 426 OK, 481884f4, 2026-09-25T04:59:40Z). Of %d '
            'integrated runs, SM8 was red in %d (%s).'
            % (len(integ), len(red_i), ', '.join(red_i))),
        'change': ('integrated_runs_on_the_pre_fix_sm8_bytes and solo_runs_on_the_pre_fix_sm8_'
                   'bytes list every run with its tree, UTC, digest and how its SM8 verdict is '
                   'known; rates recomputes both rates; every log that exists is archived '
                   '(earlier_runs_logs.tar.gz).'),
        'status': 'corrected in this receipt'})

    # ---------------------------------------------------------------- finding 2
    r['post_fix_integrated_run'] = {
        'status': 'OWED: no live_ab_controls full suite ran in this step',
        'ruling': ("root 16:15, reviews/sm8_diagnosis_interim_20260925_1615.md (origin/main "
                   "03e98ec): one passing, final-code-pinned integrated run, plus the "
                   "deterministic pre-fix/fixed forced controls, the restart-check mutation "
                   "control, complete corrected attempt provenance and unchanged production "
                   "hashes, is enough for this repaired control; a second broad run only to "
                   "collect another green is not required; any new unexplained red is a "
                   "blocker to diagnose, not a reason to rerun"),
        'will_come_from': ("receipt R's run of every suite once at the final head (the owner's "
                           "instruction for this step, relaying the ruling: no full suite here, "
                           "so the hour is not spent twice). The code this receipt describes is "
                           "final at " + fix_commit + " (test-control file only)."),
        'reading': ('until that run exists, the post-fix evidence is the design (the first '
                    'process exits on RECEIVING the first task call, so no call is answered and '
                    'the restart is required), the forced interleavings, SM8\'s precondition, '
                    'which now FAILS whenever the first process answers a task completion '
                    '(finding 3), and the restart-check mutation control. Solo greens cannot '
                    'separate fixed from unfixed code at the pre-fix solo rate (%s).'
                    % r['rates']['solo_pre_fix'])}
    r['review_findings'].append({
        'id': 2, 'severity': 'medium',
        'claim': 'the fix was never checked in the integrated suite; 30 green solo loops '
                 'cannot tell fixed from unfixed code',
        'reproduced': True,
        'reproduction': ('the 1503 receipt lists the full suites under not_run, and no '
                         'live_ab_controls full-suite log exists in the session work area '
                         'after v4 full2 (12:21:41Z); the pre-fix solo red rate is %s'
                         % r['rates']['solo_pre_fix']),
        'change': ('none in this step, by root\'s 16:15 ruling (post_fix_integrated_run): the '
                   'integrated run is owed and comes from receipt R. A --test discover mode for '
                   'sm8_attempts.py was drafted for it and withdrawn before commit (fix.runner)'),
        'status': 'OWED (receipt R)'})

    # ---------------------------------------------------------------- finding 3
    r['fix'] = {
        'commit': fix_commit,
        'files_sha256_at_the_commit': fix_files,
        'production_files_changed': [],
        'test': (
            'tests_sm_entry.SM8Case.assertFlipPrecedesTheRestart also asserts that no '
            'llm_response answers a call SENT before the server_down (worker t_send_ns < chain '
            't_mono_ns of the server_down: before it no other process existed to answer): the '
            'first process answered no task completion. SM8AtTheRestart.test_control_the_same_'
            'crash_without_the_change_restarts also asserts the entry exit 0 and the whole '
            'lifecycle [server_started, server_down(exit), server_stopped, server_restarted, '
            'server_stopped, trial_ended] (every preserved post-fix control run had exactly '
            'that).'),
        'checked_against_the_1503_trees': facts['old_answered_counts'],
        'checked_against_the_1503_trees_reading': (
            'the new precondition over every preserved tree of the 1503 attempts: 0 answered '
            'in every post-fix SM8/SM8c/SM8fy tree that has a server_down, 1 answered in every '
            'pre-fix tree that has one (none in the red SM8 tree of attempt 14 and in three trees '
            'refused before seq 0 by the host gate: SM8 of attempts 6 and 8, SM8c of attempt 7)'),
        'runner': ('every attempt of this step ran through sm8_attempts.py loop/child. In the '
                   'mutation clones old_mutA..new_mutD, in the preslow clone and for new_sm8 the '
                   'runner was a draft variant (sha256 '
                   'ed6ff9f3..., fixsm8/sm8_attempts_runner_variant.py in this_step_runs.tar.gz) '
                   'that only ADDS --test discover, --preserve-prefix and --timeout-s; with '
                   'their defaults it runs the child exactly as the committed tool (2e612b69) '
                   'does. The variant was withdrawn (root 16:15: no full suite in this step); '
                   'new_forced and new_mutB ran the committed tool'),
        'tested_bytes': ('new_sm8, new_mutA, new_mutC and new_mutD ran tests_sm_entry.py before '
                         'a docstring-only edit (sha256 6ea09ef7...; the diff to the committed '
                         '9e1b6d1d... is three docstring lines of assertFlipPrecedesTheRestart); '
                         'new_forced and new_mutB ran the committed bytes. Each run records its '
                         'files in runs/<label>/files.sha256 and each clone\'s whole diff in '
                         'fixsm8/clones_<label>.diff'),
        'mutations': {
            'A': 'tests_sm_entry: SM8Case.crash_scenarios back to exit_after_responses 2',
            'C': 'eb1c_llama_shim: exit_before_response answers the call, flushes, then '
                 'counts, flips and exits',
            'B': 'lab_server.start: a restart tolerates serving-manifest problems (the '
                 'review\'s restart-check mutation)',
            'D': 'lab_orchestrator.main: a trial that ENDED exits 4, not 0',
            'SLOW': 'eb1c_llama_shim at 90219f2: time.sleep(0.05) after the N-th response is '
                    'written, before the flip and exit (a perturbation of the pre-fix bytes)',
            'applied_by': 'fixsm8/mutate.py in this_step_runs.tar.gz (each replacement must '
                          'match exactly once); every clone\'s porcelain and file digests are '
                          'in its runs/<label>/tree_state.txt and files.sha256'},
        'this_step_runs': step}
    r['review_findings'].append({
        'id': 3, 'severity': 'low',
        'claim': 'the SM8 precondition does not catch a reversion to exit_after_responses; only '
                 'the forced class does',
        'reproduced': True,
        'reproduction': ('old_mutA (bebeb5a test code, mutation A): SM8 %s; old_mutC (mutation '
                         'C): SM8 %s -- the unchanged precondition passes both reversions'
                         % (st('old_mutA', 'sm8'), st('old_mutC', 'sm8'))),
        'change': 'the answered-before-the-server_down assertion (fix.test), commit ' + fix_commit,
        'control_fails_before_passes_after': (
            'after: new_mutA SM8 %s, new_mutC SM8 %s (assertion lines %s / %s); unmutated: '
            'new_sm8 SM8 %s, control %s; new_forced fixed %s, pre-fix %s'
            % (st('new_mutA', 'sm8'), st('new_mutC', 'sm8'), st('new_mutA', 'assertion_lines'),
               st('new_mutC', 'assertion_lines'), st('new_sm8', 'sm8'), st('new_sm8', 'control'),
               st('new_forced', 'forced_fixed_scenario'),
               st('new_forced', 'forced_pre_fix_scenario'))),
        'not_done': ('SM8ForcedInterleaving was not merged into the SM8AtTheRestart class: SM8 '
                     'now fails the reversion by itself, and the module and the full suite run '
                     'both classes'),
        'status': 'fixed'})

    # ---------------------------------------------------------------- finding 4
    r['first_divergent_event'] = {
        'red': old['first_divergent_event']['red'],
        'event': ('the SECOND llm_response of the only pair before any server_down: both task '
                  'calls answered by the first process (pid 91505) -- '
                  'task_completions_answered_by_first_pid 2 in red attempt 14 against 1 in '
                  'each of the 27 greens. The 1503 wording ("seq 21: llm_response {arrival 2, '
                  'call_index 0, http_status 200}, in NO green chain") is wrong as worded: '
                  'green attempt 26 (busy10) has llm_response for arrival 2 (its arrival 1 got '
                  'the connection error).'),
        'attempt_26_first_call_outcomes': next(
            a['trees']['SM8']['first_call_outcomes'] for a in old['attempts']
            if a['index'] == 26 and a['label'] == 'busy10'),
        'unchanged': 'compared_with, consequence_chain, not_divergences, worker_side of the '
                     '1503 receipt'}
    r['review_findings'].append({
        'id': 4, 'severity': 'low',
        'claim': 'the named divergent event occurs in green attempt 26',
        'reproduced': True,
        'reproduction': 'the 1503 attempts[] busy10 index 26 trees.SM8.first_call_outcomes = %s'
                        % json.dumps(r['first_divergent_event']['attempt_26_first_call_outcomes'],
                                     sort_keys=True),
        'change': 'first_divergent_event restated', 'status': 'corrected in this receipt'})

    # ---------------------------------------------------------------- finding 5
    r['cause_reproduced_on_the_pre_fix_shim'] = {
        'what': ('90219f2 (the pre-fix bytes) plus ONE perturbation, mutation SLOW: a 50 ms '
                 'sleep between the N-th response being written and the flip/exit -- it widens '
                 'the window the cause names and changes nothing else'),
        'runs': step.get('preslow_r'),
        'tree_signatures': signatures('preslow_r'),
        'every_SM8_tree_has_attempt_14s_signature': all(
            x['entry_returncode'] == 0 and x['server_stopped_returncodes'] == [9]
            and x['task_completions_answered_by_first_pid'] == 2
            and x['flip_target_bytes_changed'] and x['lifecycle'] == [
                'server_started', 'server_stopped', 'trial_ended']
            for x in signatures('preslow_r') if x['tree'].endswith('/SM8')),
        'reading': ('with the window widened, the pre-fix scenario gives the diagnosed red '
                    'every time: SM8 %s, and the no-flip control %s (see '
                    'pre_fix_control_shared_the_race). This is a perturbed reproduction, not '
                    'the unmodified bytes; the unmodified bytes went red %s in the solo loops.'
                    % (st('preslow_r', 'sm8'), st('preslow_r', 'control'),
                       r['rates']['solo_pre_fix']))}
    r['review_findings'].append({
        'id': 5, 'severity': 'low',
        'claim': 'the deterministic reproduction used the post-fix shim, not the pre-fix bytes',
        'reproduced': True,
        'reproduction': 'the 1503 fix.controls[0] forces the pre-fix SCENARIO with the post-fix '
                        'shim (hold_until_written exists only in 292a8a9)',
        'change': 'cause_reproduced_on_the_pre_fix_shim (my runs; the review ran the same '
                  'perturbation, runs preslow in review_runs)',
        'status': 'done'})

    # ---------------------------------------------------------------- finding 6
    ctrl_red_i = [x['run'] for x in integ if any(CTRL in h for h in x.get('failures') or [])]
    ctrl_red_s = [x['run'] for x in solo if any(CTRL in h for h in x.get('failures') or [])]
    ctrl_red_loop = ['attempt %d (%s)' % (a['index'], control_mode(a)) for a in pre_loop
                     if a['verdicts'].get(CTRL) not in ('ok',)]
    r['pre_fix_control_shared_the_race'] = {
        'statement': ('the pre-fix no-flip control scripted the same "answered, then died" '
                      'crash, so its greens were not independent of SM8\'s race. It never went '
                      'red on the unperturbed bytes (integrated failures naming it: %s; solo: '
                      '%s; diagnosis loop non-ok: %s) while SM8 did at least %d times; with the '
                      'window widened (mutation SLOW) it failed %s. The difference is '
                      'consistent with the flip\'s file I/O being the window (the control does '
                      'no flip) -- not measured.'
                      % (ctrl_red_i, ctrl_red_s, ctrl_red_loop,
                         len(red_i) + len(red_s) + len(pre_loop_red),
                         st('preslow_r', 'control'))),
        'post_fix_control': 'now asserts exit 0 and the whole lifecycle ending in trial_ended'}
    r['review_findings'].append({
        'id': 6, 'severity': 'low',
        'claim': 'the pre-fix control shared the race; the post-fix control never asserts the '
                 'entry\'s exit code',
        'reproduced': True,
        'reproduction': ('preslow control %s; old_mutD (bebeb5a test code, a normal end exits '
                         '4): control %s -- the unchanged control passes a wrong exit'
                         % (st('preslow_r', 'control'), st('old_mutD', 'control'))),
        'change': 'control assertions (fix.test), commit ' + fix_commit,
        'control_fails_before_passes_after': ('after: new_mutD control %s (%s); unmutated '
                                              'control %s' % (st('new_mutD', 'control'),
                                                              st('new_mutD', 'assertion_lines'),
                                                              st('new_sm8', 'control'))),
        'status': 'fixed'})

    # ---------------------------------------------------------------- finding 7
    hist = {}
    for c in ('5ae183d', '03fe0ca', 'f54d215', '90219f2', fix_commit):
        hist[c] = {f: G.blob_sha(c, 'experiments/live_ab_controls/' + f)[:8] for f in
                   ('tests_sm_entry.py', 'eb1c_llama_shim.py', 'sm_fixture.py',
                    'tests_eb1_entry.py')}
    r['pins'] = {
        'pre_fix_sha256': dict(pre_pins),
        'pre_fix_bytes_identical_at': ('before the fix 292a8a9, tests_sm_entry.py and '
                                       'eb1c_llama_shim.py last changed at 5ae183d, '
                                       'sm_fixture.py at 03fe0ca '
                                       '(2026-09-24T15:44:23Z); all three identical at every '
                                       'commit 03fe0ca..90219f2'),
        'tests_eb1_entry_per_run': ('35259026 (03fe0ca..c001354) for every run up to repro '
                                    'run15; f83aa367 (f54d215..) for v4 full1/full2, v4 '
                                    'sm8_1-3 and the diagnosis; repro run25 ran with f54d215 '
                                    'uncommitted (f83aa367 if that edit was already made); '
                                    'per run in the runs tables'),
        'tests_eb1_entry_sha256': {'35259026': G.blob_sha('03fe0ca', 'experiments/'
                                                          'live_ab_controls/tests_eb1_entry.py'),
                                   'f83aa367': G.blob_sha('f54d215', 'experiments/'
                                                          'live_ab_controls/tests_eb1_entry.py')},
        'history_prefix8': hist,
        'fix_commit_files': fix_files}
    r['review_findings'].append({
        'id': 7, 'severity': 'low',
        'claim': 'sm_fixture last changed at 03fe0ca, not 5ae183d; tests_eb1_entry changed at '
                 'f54d215, one pin cannot cover every run',
        'reproduced': True, 'reproduction': 'pins.history_prefix8 (git show <c>:<file> | sha256)',
        'change': 'pins', 'status': 'corrected in this receipt'})

    # ---------------------------------------------------------------- finding 8
    chk = facts['old_attempts_check']
    r['archives'] = dict(archives)
    r['archives_reading'] = {
        'diagnosis_1503_attempts.tar.gz': (
            'all %d attempts of the 1503 receipt: stdout.log, attempt.json, the per-tree digest '
            'records (trees/<name>.json), every tree\'s trial chain segments and shim state '
            '(launches, scenarios, flips); the six attempts.jsonl ledgers (%d rows), the loop '
            'logs and CANDIDATES.txt. Every attempts[].stdout_sha256 of the 1503 receipt '
            'matches its archived stdout.log (mismatches: %s, missing: %s). Also a copy of the '
            'loop tool the work area names sm8_attempts_as_run_attempts_1_on.py (as found; the '
            '1503 receipt says the version of attempts 1-8 was not preserved byte-exact, and '
            'this copy is not claimed to be it)'
            % (chk['attempts'], chk['ledger_rows_total'], chk['stdout_digest_mismatches'],
               chk['missing'])),
        'earlier_runs_logs.tar.gz': ('every log of integrated_runs / solo_runs that exists '
                                     '(the pin-tool runs\' output exists only as the digest in '
                                     'its committed receipt), their run records, and the '
                                     'review\'s ledgers and scripts (review_runs/)'),
        'this_step_runs.tar.gz': ('every attempt of this step: stdout, attempt.json, tree '
                                  'digest records, trial chains and shim state; the WHOLE '
                                  'SM8* trees of the two integrated runs; the scripts that '
                                  'made them')}
    r['review_findings'].append({
        'id': 8, 'severity': 'low',
        'claim': 'only 5 of 71 attempts are in the repository',
        'reproduced': True,
        'reproduction': 'git ls-files results/live_ab/sm8_diagnosis lists 29 files for '
                        'attempts 6, 13, 14, 101 and 206',
        'change': 'archives (diagnosis_1503_attempts.tar.gz, earlier_runs_logs.tar.gz)',
        'status': 'done'})

    # ---------------------------------------------------------------- finding 9
    r['attempts_run_on_a_non_quiescent_host'] = {
        'marked': ('forced_dev 1 and forced 201-204: 1-minute load 15.5, 16.9, 8.9, 5.5, 4.7, '
                   'decaying after the busy probes (fixed_busy stopped its 10 loops at '
                   '14:44:41Z; 201 started 14:45:22Z). The loop\'s soft gate read clean before '
                   'each, yet the controls\' real gate refused tests in 201-204 '
                   '(baseline-active); root\'s quiescent-host condition was not met for them'),
        'later_forced_attempts': ('205-210: 1-minute load 2.1-3.0 but 5-minute 12.5 -> 5.3, '
                                  'still decaying'),
        'loads': facts['old_forced_loads'],
        'rerun': ('this step ran SM8ForcedInterleaving 3 times at the fixed test code with no '
                  'busy probe (new_forced): fixed scenario %s, pre-fix scenario %s, 1-minute '
                  'load before %s' % (st('new_forced', 'forced_fixed_scenario'),
                                      st('new_forced', 'forced_pre_fix_scenario'),
                                      st('new_forced', 'loadavg_1min_before')))}
    r['review_findings'].append({
        'id': 9, 'severity': 'low',
        'claim': 'the forced loop started 41 s after the busy probe; 201-204 ran on a loaded '
                 'host',
        'reproduced': True,
        'reproduction': 'attempts_run_on_a_non_quiescent_host.loads (from the 1503 attempts[])',
        'change': 'attempts_run_on_a_non_quiescent_host', 'status': 'marked in this receipt'})

    r['restart_check_mutation_control'] = {
        'what': ('mutation B against the FINAL test code (new_mutB): the restart no longer '
                 'refuses a serving-manifest problem, so a production defect of exactly the '
                 'kind SM8 exists to catch'),
        'result': 'SM8 %s; control %s; assertion lines %s' % (
            st('new_mutB', 'sm8'), st('new_mutB', 'control'), st('new_mutB', 'assertion_lines')),
        'the_reviews_run': ('the review ran the same mutation against the 292a8a9 test code: '
                            'review_runs mutB (%s)' % review['mutB']['by_tag_and_verdicts'])}
    r['closing_stop_disposition'] = (
        'root 16:15 (reviews/sm8_diagnosis_interim_20260925_1615.md): the closing-stop question '
        'of the 1503 observation_for_root_not_changed is resolved narrowly -- when every call of '
        'the final pair was answered and no restart was owed before a normal trial end, the '
        'observed nonzero server_stopped.returncode is kept in the chain and receipt; no '
        'production change, no event reinterpretation, no amendment. A later live case with a '
        'missing outcome or resource/usage record is assessed separately.')
    r['observation_for_root_not_changed'] = old['observation_for_root_not_changed']
    r['production_sha256_unchanged'] = {
        rel: G.blob_sha(fix_commit, rel) for rel in (
            'experiments/live_ab/config.json', 'experiments/live_ab/lab_hostcheck.py',
            'experiments/live_ab/lab_mock_server.py', 'experiments/live_ab/lab_orchestrator.py',
            'experiments/live_ab/lab_server.py', 'experiments/live_ab/lab_serving_manifest.py')}
    r['production_sha256_unchanged_reading'] = (
        'each equals the 1503 receipt pins.production_sha256_unchanged_by_this_work (checked: '
        '%s); files under experiments/live_ab/ that git diff 90219f2..%s changes: %s'
        % (all(r['production_sha256_unchanged'][k] == v for k, v in
               old['pins']['production_sha256_unchanged_by_this_work'].items()
               if k in r['production_sha256_unchanged']), fix_commit,
           [x for x in G.git('diff', '--name-only', '90219f2', fix_commit).split()
            if x.startswith('experiments/live_ab/')]))
    r['what_this_does_not_establish'] = [
        'why the integrated runs were redder than the solo runs (rates.why_integrated_runs_'
        'are_redder is a hypothesis)',
        'post-fix integrated reliability: the final-code-pinned integrated run is OWED and '
        'comes from receipt R (post_fix_integrated_run)',
        'anything about the durable llama.cpp build: the library is the compiled sm_fixture '
        'test double',
        'any suite at the fix commit: the fix changes one test-control file; what ran after '
        'this receipt was written is in the commit message that adds it']
    r['runs_of_this_step'] = (
        'every run of this step is in fix.this_step_runs, red or green, host-gate refusals '
        'included: chain1 (16:10:54Z-16:35Z) new_sm8, old_mutA, new_mutA, old_mutC, new_mutC, '
        'old_mutD, new_mutD, then preslow attempt 1 INTERRUPTED (interruption_incident); '
        'chain1b (new_mutB, queued behind chain1) never started; chain3 re-ran what was '
        'interrupted or never ran: preslow_r, new_forced, new_mutB. No full suite ran. Nothing '
        'else was run before this receipt was written.')
    r['interruption_incident'] = {
        'what': ('two instances of this fix step ran at once. The owner\'s 16:26Z update '
                 '(relaying root 16:15) accidentally started a second instance of the step\'s '
                 'agent; the original instance, running since about 15:55Z, saw the other\'s '
                 'edits and reported it, and at 16:35Z the owner stopped the whole SM8 workflow. '
                 'The owner then named the instance that received the 16:26Z update as the only '
                 'writer. The owner reports the other instance committed nothing and did not '
                 'touch the owner worktree after these edits began; a listing of every file in '
                 'the session work area and /private/tmp/labsbx changed after 15:55Z shows no '
                 'attempt directory, test log, ledger or temporary test tree other than this '
                 'step\'s own; and the shared fixture-use log /private/tmp/labsbx/'
                 'eb1c_sm_fixture_uses.jsonl, appended by every control that builds the '
                 'compiled test double, has no entry between 15:55:28Z (the review\'s last) '
                 'and 16:11:05Z, and its 40 entries from 16:11:05Z to 16:35:18Z are exactly '
                 'chain1\'s (22 test processes: 17 two-test attempts, 4 one-test attempts, the '
                 'interrupted one). One file in this step\'s own directory was written by '
                 'the other instance: tmp/wt_now.diff (16:33:08Z, 3,986 B, sha256 f5a803d6e748260989b34f15a8a14ef00db91fbd8361755781fbb5870b76a6e4), a '
                 'copy of the owner-worktree diff at that moment (not used here).'),
        'effect_on_runs': ('the stop killed this step\'s chain1 during preslow attempt 1 '
                           '(started 16:34:45Z): its control SM8c had finished (entry exit 0, '
                           'tree preserved 16:35:18Z) and its SM8 test was running; no stdout '
                           'or ledger row was written, so it has NO verdict and is not counted. '
                           'Its temporary tree, left in /private/tmp/labsbx by the kill, was '
                           'copied to runs/preslow/loop/attempt_01/trees/'
                           'SM8_interrupted_leftover and then removed; no process of it was '
                           'alive. chain1b (new_mutB) had not started. chain3 re-ran preslow '
                           '(as preslow_r), new_forced and new_mutB.'),
        'interrupted_attempt_trees': signatures('preslow'),
        'results_the_other_instance_reported': ('the owner relayed chain1 results the other '
                                                'instance read from this step\'s logs; the '
                                                'counts here are computed from the logs '
                                                'themselves, not from that report')}
    return r
