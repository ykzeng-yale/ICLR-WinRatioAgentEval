"""Deterministic tar.gz archives with a per-member digest manifest (session work area tool)."""
import gzip
import hashlib
import io
import os
import tarfile
import time
from pathlib import Path


def sha256_file(path) -> str:
    h = hashlib.sha256()
    with open(path, 'rb') as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


def utc(ts: float) -> str:
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime(ts))


def make_archive(out: Path, members: list) -> dict:
    """``members``: [(arcname, source path)].  Sorted by arcname; owner fields blanked; the
    file mtime is kept (it is evidence); the gzip header mtime is 0.  Returns the archive's
    record with every member's size and SHA-256."""
    members = sorted(set(members))
    names = [a for a, _ in members]
    assert len(names) == len(set(names)), 'duplicate arcname'
    out = Path(out)
    assert not out.exists(), 'write-once: %s exists' % out
    raw = io.BytesIO()
    rows = []
    with tarfile.open(fileobj=raw, mode='w', format=tarfile.PAX_FORMAT) as tar:
        for arc, src in members:
            src = Path(src)
            st = src.stat()
            info = tarfile.TarInfo(arc)
            info.size = st.st_size
            info.mtime = int(st.st_mtime)
            info.mode = 0o644
            info.uid = info.gid = 0
            info.uname = info.gname = ''
            with open(src, 'rb') as fh:
                tar.addfile(info, fh)
            rows.append({'name': arc, 'bytes': st.st_size, 'sha256': sha256_file(src),
                         'mtime_utc': utc(st.st_mtime)})
    gz = io.BytesIO()
    with gzip.GzipFile(fileobj=gz, mode='wb', mtime=0, compresslevel=9) as g:
        g.write(raw.getvalue())
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(gz.getvalue())
    listing = ''.join('%s  %s\n' % (r['sha256'], r['name']) for r in rows)
    return {'bytes': out.stat().st_size, 'sha256': sha256_file(out), 'members': len(rows),
            'member_digests_sha256': hashlib.sha256(listing.encode('utf-8')).hexdigest(),
            'member_digests_rule': 'sha256 of the lines "<member sha256>  <member name>\\n" in '
                                   'member-name order', 'rows': rows}


def verify_archive(path: Path, record: dict) -> list:
    """Re-read the archive and compare every member with the record; returns problems."""
    problems = []
    if sha256_file(path) != record['sha256']:
        problems.append('archive digest')
    want = {r['name']: r for r in record['rows']}
    seen = set()
    with tarfile.open(path, 'r:gz') as tar:
        for m in tar.getmembers():
            data = tar.extractfile(m).read()
            r = want.get(m.name)
            if r is None:
                problems.append('unexpected member %s' % m.name)
                continue
            seen.add(m.name)
            if hashlib.sha256(data).hexdigest() != r['sha256'] or len(data) != r['bytes']:
                problems.append('member %s differs' % m.name)
    for name in set(want) - seen:
        problems.append('missing member %s' % name)
    return problems
