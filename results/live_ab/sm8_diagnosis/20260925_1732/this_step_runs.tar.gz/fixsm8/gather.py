"""Read-only gathering for the superseding SM8 diagnosis receipt (session work area tool).

Every number the receipt states about runs is computed here from the files; nothing is
executed.  ``python gather.py`` prints the gathered facts as JSON."""
import glob
import json
import os
import re
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from archive_lib import sha256_file, utc  # noqa: E402

S = Path('/private/tmp/claude-501/-Users-yukangzengcmac-ICLR-WinRatioAgentEvals/'
         '35a3ef1c-e430-45ac-b78e-94ba942c34a1/scratchpad')
W = S / 'wt-eb1'
F = S / 'repair' / 'fixsm8'
DIAG = S / 'sm8diag'
REVIEW = S / 'repair' / 'review_tmp' / 'sm8'
OLD = W / 'results' / 'live_ab' / 'SM8_DIAGNOSIS_20260925_1503.json'
SM8 = 'test_sm8_a_library_changed_before_the_restart_refuses_it'
CTRL = 'test_control_the_same_crash_without_the_change_restarts'
LABEL_DIR = {'quiescent': 'quiescent', 'busy10': 'busy', 'fixed_quiescent': 'fixed',
             'fixed_busy10': 'fixed_busy', 'forced_dev': 'forced_dev', 'forced': 'forced'}
PRE_PINS = {'tests_sm_entry.py': 'ac4257fbdaa8cc4d4230c32ab53e5c81d550ad1e1658e111c595f05bf02df76d',
            'eb1c_llama_shim.py': '71ececb3a4b43b2e290fe4affb2f74fb2042867fa8492a0371c02285195b1da0',
            'sm_fixture.py': '9d3f954d4d997c563d742d881aa74e7bd8e0cf9b50193cf85a674706a93166d6'}


def git(*args, cwd=W) -> str:
    return subprocess.run(['git', '-C', str(cwd)] + list(args), capture_output=True,
                          text=True, check=True).stdout


def blob_sha(commit: str, rel: str) -> str:
    import hashlib
    data = subprocess.run(['git', '-C', str(W), 'show', '%s:%s' % (commit, rel)],
                          capture_output=True, check=True).stdout
    return hashlib.sha256(data).hexdigest()


def birth(path: Path) -> str:
    st = os.stat(path)
    return utc(getattr(st, 'st_birthtime', st.st_mtime))


def sm8_verdict_from_log(text: str) -> tuple:
    """(verdict, evidence) of the SM8 test in a unittest log."""
    m = re.search(r'^%s \(tests_sm_entry\.SM8AtTheRestart\.%s\) \.\.\. (\w+)$' % (SM8, SM8),
                  text, re.M)
    if m:
        return ('green' if m.group(1) == 'ok' else 'RED'), 'verbose line: ... %s' % m.group(1)
    if re.search(r'^(FAIL|ERROR): %s ' % SM8, text, re.M):
        block = text.split('%s: %s' % ('FAIL' if 'FAIL: ' + SM8 in text else 'ERROR', SM8),
                           1)[1].split('=' * 70)[0]
        last = [ln for ln in block.splitlines() if ln.startswith('AssertionError')]
        return 'RED', 'FAIL block: %s' % (last[-1] if last else '?')
    if re.search(r'^(FAIL|ERROR): .*tests_sm_entry', text, re.M) or 'tests_sm_entry' in \
            ''.join(re.findall(r'^ERROR: .*$', text, re.M)):
        return 'unknown', 'a tests_sm_entry failure/error header other than SM8'
    return 'green', ('not among the FAIL/ERROR headers of a non-verbose discover run whose '
                     'pattern includes tests_sm_entry.py (an import failure would be an ERROR)')


def ran_line(text: str) -> str:
    ran = re.findall(r'^Ran \d+ tests? in [\d.]+s$', text, re.M)
    res = re.findall(r'^(OK.*|FAILED.*)$', text, re.M)
    return '%s | %s' % (ran[-1] if ran else '?', res[-1] if res else '?')


def failure_headers(text: str) -> list:
    return [re.sub(r' \(.*$', '', h) for h in re.findall(r'^(?:FAIL|ERROR): (.*)$', text, re.M)]


def log_row(rel: str) -> dict:
    p = S / rel
    text = p.read_text('utf-8', 'replace')
    v, ev = sm8_verdict_from_log(text)
    return {'log': rel, 'log_sha256': sha256_file(p), 'log_bytes': p.stat().st_size,
            'log_created_utc': birth(p), 'log_modified_utc': utc(p.stat().st_mtime),
            'result': ran_line(text), 'failures': failure_headers(text), 'sm8': v,
            'sm8_evidence': ev}


# ------------------------------------------------------------------ integrated runs
INTEGRATED = [
    {'run': 'pin-tool suite run of receipt 1635', 'receipt':
        'results/live_ab/HARNESS_PIN_SUCCESSOR_20260924_1635.json',
     'tree': 'clean checkout of 03fe0ca (receipt repository.head; working_tree_porcelain [])',
     'tests_eb1_entry': '35259026', 'in_1503_count': False},
    {'run': 'pin-tool suite run of receipt 1732', 'receipt':
        'results/live_ab/HARNESS_PIN_SUCCESSOR_20260924_1732.json',
     'tree': '591ebcd; porcelain lists only the pin tool and its test as modified',
     'tests_eb1_entry': '35259026', 'in_1503_count': False},
    {'run': 'comply full1', 'log': 'repair/comply/logs/full1_live_ab_controls.log',
     'tree': 'the owner worktree at 159e747 with the compliance step uncommitted (committed '
             'as 7ebffad); run by repair/comply/logs/suites.sh after live_ab, tools, serving',
     'tests_eb1_entry': '35259026', 'in_1503_count': True},
    {'run': 'comply full2', 'log': 'repair/comply/logs/full2_live_ab_controls.log',
     'tree': 'the owner worktree, the compliance step final bytes (committed as 7ebffad)',
     'tests_eb1_entry': '35259026', 'in_1503_count': True},
    {'run': 'eb1_1905 run2', 'log': 'eb1_1905/run2_controls.log',
     'tree': 'the owner worktree at 7ebffad with the root 19:05 fix uncommitted (committed as '
             '9f0aff6 at 21:05:29Z); disclosed in HARNESS_PIN_SUCCESSOR_20260925_0027.json '
             'disclosed_red_runs_before_this_successor[12] as "run2 live_ab_controls 426 OK"',
     'tests_eb1_entry': '35259026', 'in_1503_count': False},
    {'run': 'v3 base', 'log': 'v3logs/base_controls.log',
     'tree': 'head 9f0aff6 (the log\'s START line); recorded in '
             'REPAIR_AMENDMENT_V3_RECEIPT_20260924_2218.json', 'tests_eb1_entry': '35259026',
     'in_1503_count': False},
    {'run': 'v3 after', 'log': 'v3logs/after_controls.log',
     'tree': 'head 9f0aff6 (the log\'s START line) with the amendment v3 changes uncommitted '
             '(committed as 56df17f at 23:18:17Z)', 'tests_eb1_entry': '35259026',
     'in_1503_count': False},
    {'run': 'pin-tool suite run of receipt 0027', 'receipt':
        'results/live_ab/HARNESS_PIN_SUCCESSOR_20260925_0027.json',
     'tree': 'clean checkout of 79e60d4 (receipt repository.head; working_tree_porcelain [])',
     'tests_eb1_entry': '35259026', 'in_1503_count': False},
    {'run': 'final_fix full_controls1', 'log': 'final_fix/logs/full_controls1.log',
     'tree': 'a clone at 8f0b4ae (final_fix/head) plus untracked tests_guard_controls.py and '
             'zz_repro_* probes; its SM8 files hash to the pre-fix pins today',
     'tests_eb1_entry': '35259026', 'in_1503_count': False},
    {'run': 'review final full_controls (clean clone)',
     'log': 'repair/review_tmp/final/logs/combined_live_ab_controls.log',
     'tree': 'a clean clone at 8f0b4ae (repair/review_tmp/final/clone or clone2; git status '
             'porcelain empty, unlike the ro clone which carries the same untracked zz_repro_* '
             'probes as final_fix); tests_sm_entry/eb1c_llama_shim/sm_fixture hash to the '
             'pre-fix pins', 'tests_eb1_entry': '35259026', 'in_1503_count': False},
    {'run': 'repro run15', 'log': 'repro_eb1eb5/logs/run15_full_c001354_live_ab_controls.log',
     'tree': 'a full clone at c001354 (repro_eb1eb5/full); SM8 files unchanged since its '
             'checkout at 07:05:27Z; its tests_eb1_entry.py was modified at 08:26:50Z, after '
             'the run ended', 'tests_eb1_entry': '35259026', 'in_1503_count': False},
    {'run': 'repro run25', 'log': 'repro_eb1eb5/logs/run25_wt_live_ab_controls.log',
     'tree': 'the owner worktree at c001354 with the f54d215 changes uncommitted (its 458 tests '
             'include the 16 tests_repro_inputs tests f54d215 adds; committed at 09:30:11Z)',
     'tests_eb1_entry': 'f83aa367 if the uncommitted f54d215 edit was already made (not '
                        'recorded)', 'in_1503_count': False},
    {'run': 'v4 full1', 'log': 'v4/full1/live_ab_controls.log',
     'tree': 'f54d215 plus the uncommitted bdee21b changes; v4/full1/summary.txt porcelain '
             'names no SM8 file', 'tests_eb1_entry': 'f83aa367', 'in_1503_count': True},
    {'run': 'v4 full2', 'log': 'v4/full2/live_ab_controls.log',
     'tree': 'bdee21b plus the uncommitted v4 amendment files (committed as 90219f2); '
             'v4/full2/summary.txt porcelain names no SM8 file', 'tests_eb1_entry': 'f83aa367',
     'in_1503_count': True},
]

SOLO = [
    {'run': 'comply rerun_sm8_%d' % i, 'log': 'repair/comply/logs/rerun_sm8_%d.log' % i,
     'tree': 'as comply full2', 'tests_eb1_entry': '35259026', 'in_1503_count': True}
    for i in (1, 2, 3)] + [
    {'run': 'v4 sm8_%d' % i, 'log': 'v4/sm8_%d.log' % i, 'tree': 'as v4 full1',
     'tests_eb1_entry': 'f83aa367', 'in_1503_count': True} for i in (1, 2, 3)]


def pin_run(receipt_rel: str) -> dict:
    d = json.loads((W / receipt_rel).read_text('utf-8'))
    (r,) = [x for x in d['solo_run_suites']['runs'] if x.get('suite') == 'live_ab_controls']
    res = r['result']
    return {'receipt_sha256': sha256_file(W / receipt_rel), 'head': d['repository']['head'],
            'argv_tail': r['argv'][2:], 'start_utc': r['start_utc'], 'end_utc': r['end_utc'],
            'result': '%s | %s' % (res['ran_line'], res['verdict_line']),
            'tests_sm_entry_in_plan': r['plan']['per_module'].get('tests_sm_entry'),
            'stderr_sha256': r['stderr_sha256'], 'stderr_bytes': r['stderr_bytes'],
            'sm8': 'green' if res['passed'] else 'unknown',
            'sm8_evidence': 'the run passed (-v, %d of %d planned tests, tests_sm_entry %s in '
                            'the plan); its unittest output is recorded only by digest and '
                            'tail in the committed receipt' % (res['ran'], res['planned'],
                                                              r['plan']['per_module'].get(
                                                                  'tests_sm_entry'))}


def integrated() -> list:
    out = []
    for row in INTEGRATED:
        r = dict(row)
        if 'receipt' in r:
            r.update(pin_run(r['receipt']))
        else:
            r.update(log_row(r['log']))
        out.append(r)
    return out


def solo() -> list:
    return [dict(r, **log_row(r['log'])) for r in SOLO]


# ------------------------------------------------------------------ the 1503 attempts
def old_attempts_check() -> dict:
    d = json.loads(OLD.read_text('utf-8'))
    mism, missing, rows = [], [], []
    for a in d['attempts']:
        adir = DIAG / LABEL_DIR[a['label']] / ('attempt_%02d' % a['index'])
        p = adir / 'stdout.log'
        if not p.exists():
            missing.append(str(adir.relative_to(S)))
            continue
        if sha256_file(p) != a['stdout_sha256']:
            mism.append(str(adir.relative_to(S)))
        rows.append(a)
    ledgers = {lab: sum(1 for ln in (DIAG / dd / 'attempts.jsonl').read_text().splitlines()
                        if ln.strip()) for lab, dd in LABEL_DIR.items()}
    return {'attempts': len(d['attempts']), 'stdout_digest_mismatches': mism,
            'missing': missing, 'ledger_rows': ledgers,
            'ledger_rows_total': sum(ledgers.values())}


def old_forced_loads() -> list:
    d = json.loads(OLD.read_text('utf-8'))
    out = []
    for a in d['attempts']:
        if a['label'] in ('forced', 'forced_dev'):
            out.append({'index': a['index'], 'label': a['label'], 'start_utc': a['start_utc'],
                        'loadavg_before': [round(x, 2) for x in a['loadavg_before']],
                        'soft_gate_clean_before': a['host_gate_before']['clean'],
                        'verdicts': a['verdicts']})
    return out


def old_answered_counts() -> dict:
    """Per preserved tree of the 1503 attempts: llm_responses to calls sent before the first
    server_down (the new SM8 precondition), by label and tree name."""
    import collections
    c = collections.Counter()
    for lab, dd in LABEL_DIR.items():
        for tree in sorted(glob.glob(str(DIAG / dd / 'attempt_*' / 'trees' / '*'))):
            if not os.path.isdir(tree):
                continue
            ev = []
            for seg in sorted(glob.glob(os.path.join(tree, 'results', 'T4', 'events',
                                                     'seg_*.jsonl'))):
                ev += [json.loads(ln) for ln in open(seg) if ln.strip()]
            downs = [e for e in ev if e['type'] == 'server_down']
            if not downs:
                c['%s/%s: no server_down' % (lab, os.path.basename(tree))] += 1
                continue
            n = sum(1 for e in ev if e['type'] == 'llm_response'
                    and int(e['body']['t_send_ns']) < int(downs[0]['t_mono_ns']))
            c['%s/%s: %d answered before the server_down' % (lab, os.path.basename(tree), n)] += 1
    return dict(sorted(c.items()))


# ------------------------------------------------------------------ the review's runs
def review_runs() -> dict:
    out = {}
    for tag in ('pre', 'post', 'mutA', 'mutB', 'mutC', 'preslow'):
        p = REVIEW / 'runs' / tag / 'ledger.jsonl'
        rows = [json.loads(ln) for ln in p.read_text().splitlines() if ln.strip()]
        out[tag] = {'ledger': 'repair/review_tmp/sm8/runs/%s/ledger.jsonl' % tag,
                    'ledger_sha256': sha256_file(p), 'rows': len(rows),
                    'heads': sorted({r.get('head') for r in rows}),
                    'by_tag_and_verdicts': sorted(
                        '%s %s mode=%s' % (r['tag'], json.dumps(r['verdicts'], sort_keys=True),
                                           r['sm8_mode']) for r in rows)}
    return out


# ------------------------------------------------------------------ this step's runs
def step_runs() -> dict:
    out = {}
    for d in sorted(glob.glob(str(F / 'runs' / '*'))):
        label = os.path.basename(d)
        led = Path(d) / 'loop' / 'attempts.jsonl'
        if not led.exists():
            continue
        rows = [json.loads(ln) for ln in led.read_text().splitlines() if ln.strip()]
        att = []
        for r in rows:
            aj = json.loads((Path(d) / 'loop' / ('attempt_%02d' % r['index']) /
                             'attempt.json').read_text())
            fails = [ln for ln in (Path(d) / 'loop' / ('attempt_%02d' % r['index']) /
                                   'stdout.log').read_text().splitlines()
                     if ln.startswith(('AssertionError', 'FAIL:', 'ERROR:'))
                     or ln.strip().startswith('self.assert')]
            att.append({'index': r['index'], 'start_utc': r['start_utc'],
                        'end_utc': r['end_utc'], 'exit_code': r['exit_code'],
                        'loadavg_before': [round(x, 2) for x in aj['loadavg_before']],
                        'soft_gate_clean_before': aj['host_gate_before']['clean'],
                        'stdout_sha256': aj['stdout_sha256'],
                        'verdicts': {k: v for k, v in r['verdicts'].items()
                                     if v != 'not_run' or k in (SM8, CTRL)}
                        if len(r['verdicts']) < 20 else {
                            k: v for k, v in r['verdicts'].items()
                            if 'sm8' in k.lower() or k in (CTRL,) or 'forced' in k
                            or 'fixed_scenario' in k or 'pre_fix_scenario' in k
                            or v not in ('ok',)},
                        'sm8_mode': r['sm8_mode'], 'failure_lines': fails[:12]})
        files = (Path(d) / 'files.sha256').read_text().split('\n')
        state = (Path(d) / 'tree_state.txt').read_text().strip().splitlines()
        out[label] = {'tree_head': state[0] if state else None,
                      'tree_porcelain': state[1:], 'files_sha256': [f for f in files if f],
                      'attempts': att}
    return out


if __name__ == '__main__':
    print(json.dumps({'integrated': integrated(), 'solo': solo(),
                      'old_attempts_check': old_attempts_check(),
                      'old_forced_loads': old_forced_loads(),
                      'old_answered_counts': old_answered_counts(),
                      'review_runs': review_runs(), 'step_runs': step_runs()},
                     indent=1, sort_keys=True))
