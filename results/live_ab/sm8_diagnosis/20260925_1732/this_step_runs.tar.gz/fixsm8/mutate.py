"""Apply one named mutation to a scratch clone; each replacement must match exactly once.

A  tests_sm_entry: SM8's crash scenario reverted to the pre-fix exit_after_responses (review F3)
C  eb1c_llama_shim: exit_before_response answers the call first, then counts/flips/exits (F3)
B  lab_server.start: the restart tolerates serving-manifest problems (the review's restart-check
   mutation; root 16:15 lists a restart-check mutation control)
D  lab_orchestrator.main: a normally ENDED trial exits 4 instead of 0 (F6: the control's exit)
SLOW  eb1c_llama_shim at 90219f2 (pre-fix bytes): a 50 ms sleep after the N-th response is
      written and before the flip/exit (F5: the red reproduced on the pre-fix shim)
"""
import sys
from pathlib import Path

MUT = {
    'A': ('experiments/live_ab_controls/tests_sm_entry.py',
          "first['_shim'] = {'exit_before_response': 2, 'exit_code': 9, **shim_extra}",
          "first['_shim'] = {'exit_after_responses': 2, 'exit_code': 9, **shim_extra}"),
    'C': ('experiments/live_ab_controls/eb1c_llama_shim.py',
          "        if before_response:\n"
          "            _progress()\n"
          "            with lock:\n"
          "                counted[0] += 1\n"
          "                if counted[0] >= n:\n"
          "                    _exit_now()\n"
          "            original(self, body)\n"
          "            return\n",
          "        if before_response:\n"
          "            original(self, body)\n"
          "            try:\n"
          "                self.wfile.flush()\n"
          "            except OSError:\n"
          "                pass\n"
          "            _progress()\n"
          "            with lock:\n"
          "                counted[0] += 1\n"
          "                if counted[0] >= n:\n"
          "                    _exit_now()\n"
          "            return\n"),
    'B': ('experiments/live_ab/lab_server.py',
          "    if labels:\n        fail('serving_manifest', ['serving_manifest'], labels=labels)\n",
          "    if labels and kind != 'restart':\n"
          "        fail('serving_manifest', ['serving_manifest'], labels=labels)\n"),
    'D': ('experiments/live_ab/lab_orchestrator.py',
          "return {'ended': 0, 'aborted': 1, 'paused': 2, 'refused': 3}.get(status, 1)",
          "return {'ended': 4, 'aborted': 1, 'paused': 2, 'refused': 3}.get(status, 1)"),
    'SLOW': ('experiments/live_ab_controls/eb1c_llama_shim.py',
             "        if done:\n"
             "            if flip:\n"
             "                _flip(flip)\n",
             "        if done:\n"
             "            time.sleep(0.05)   # perturbation: widen the answered-then-died window\n"
             "            if flip:\n"
             "                _flip(flip)\n"),
}

clone, name = Path(sys.argv[1]), sys.argv[2]
rel, old, new = MUT[name]
p = clone / rel
s = p.read_text('utf-8')
assert s.count(old) == 1, (name, s.count(old))
p.write_text(s.replace(old, new), encoding='utf-8')
print('mutation', name, 'applied to', rel)
