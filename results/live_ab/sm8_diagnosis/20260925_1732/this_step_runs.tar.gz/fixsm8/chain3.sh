#!/bin/bash
# Re-run of what the owner's 16:35Z stop of the workflow interrupted (chain1 preslow, new_forced;
# chain1b new_mutB), one at a time.  The interrupted preslow attempt 1 stays in runs/preslow.
S=/private/tmp/claude-501/-Users-yukangzengcmac-ICLR-WinRatioAgentEvals/35a3ef1c-e430-45ac-b78e-94ba942c34a1/scratchpad
F=$S/repair/fixsm8; W=$S/wt-eb1; C=$F/clones
PY=/Users/yukangzengcmac/ICLR-WinRatioAgentEvals/.venv/bin/python
run() {
  local label=$1 root=$2 n=$3 test=$4 out=$F/runs/$1
  mkdir -p $out
  ( cd $root && git rev-parse HEAD && git status --short ) > $out/tree_state.txt 2>&1
  ( cd $root && shasum -a 256 experiments/live_ab_controls/tests_sm_entry.py experiments/live_ab_controls/eb1c_llama_shim.py experiments/live_ab_controls/sm_fixture.py experiments/live_ab_controls/tests_eb1_entry.py experiments/live_ab_controls/sm8_attempts.py experiments/live_ab/lab_orchestrator.py experiments/live_ab/lab_server.py ) > $out/files.sha256
  echo "$label start $(date -u +%FT%TZ)" >> $F/chain3.log
  ( cd $root/experiments/live_ab_controls && $PY sm8_attempts.py loop --out $out/loop --max-attempts $n --stop-after-red 99 --label $label --test $test ) > $out/loop.log 2>&1
  echo "$label exit=$? end $(date -u +%FT%TZ)" >> $F/chain3.log
  cat $out/loop.log >> $F/chain3.log
}
run preslow_r $C/preslow 3 tests_sm_entry.SM8AtTheRestart
run new_forced $W 3 tests_sm_entry.SM8ForcedInterleaving
run new_mutB $C/new_mutB 3 tests_sm_entry.SM8AtTheRestart
echo CHAIN3_DONE >> $F/chain3.log
