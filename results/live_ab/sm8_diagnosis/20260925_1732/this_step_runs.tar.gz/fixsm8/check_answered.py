"""Read-only: over preserved SM8 trees, how many llm_response events answer a request SENT
before the first server_down (i.e. answered by the first process)."""
import json, sys, glob, os, collections
def chain(tree):
    ev = []
    for seg in sorted(glob.glob(os.path.join(tree, 'results', 'T4', 'events', 'seg_*.jsonl'))):
        ev += [json.loads(l) for l in open(seg) if l.strip()]
    return ev
out = collections.Counter(); rows = []
for base in sys.argv[1:]:
    for tree in sorted(glob.glob(os.path.join(base, 'attempt_*', 'trees', '*'))):
        if not os.path.isdir(tree): continue
        name = os.path.basename(tree)
        ev = chain(tree)
        downs = [e for e in ev if e['type'] == 'server_down']
        resp = [e for e in ev if e['type'] == 'llm_response']
        if downs:
            t = downs[0]['t_mono_ns']
            before = [e['body']['arrival'] for e in resp if int(e['body']['t_send_ns']) < t]
            seq_before = [e['body']['arrival'] for e in resp if e['seq'] < downs[0]['seq']]
        else:
            before = seq_before = None
        key = (os.path.basename(base), name, None if before is None else len(before), None if seq_before is None else len(seq_before))
        out[key] += 1
for k, v in sorted(out.items(), key=str): print(k, v)
