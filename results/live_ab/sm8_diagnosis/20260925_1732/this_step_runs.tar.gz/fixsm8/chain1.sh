#!/bin/bash
# Sequential attempts for the fix step (one at a time: every control runs the real host gate).
S=/private/tmp/claude-501/-Users-yukangzengcmac-ICLR-WinRatioAgentEvals/35a3ef1c-e430-45ac-b78e-94ba942c34a1/scratchpad
F=$S/repair/fixsm8; W=$S/wt-eb1; C=$F/clones
PY=/Users/yukangzengcmac/ICLR-WinRatioAgentEvals/.venv/bin/python
run() {  # run <label> <tree root> <n> <test>
  local label=$1 root=$2 n=$3 test=$4 out=$F/runs/$1
  mkdir -p $out
  ( cd $root && git rev-parse HEAD && git status --short ) > $out/tree_state.txt 2>&1
  ( cd $root && shasum -a 256 experiments/live_ab_controls/tests_sm_entry.py experiments/live_ab_controls/eb1c_llama_shim.py experiments/live_ab_controls/sm_fixture.py experiments/live_ab_controls/tests_eb1_entry.py experiments/live_ab_controls/sm8_attempts.py experiments/live_ab/lab_orchestrator.py ) > $out/files.sha256
  echo "$label start $(date -u +%FT%TZ)" >> $F/chain1.log
  ( cd $root/experiments/live_ab_controls && $PY sm8_attempts.py loop --out $out/loop --max-attempts $n --stop-after-red 99 --label $label --test $test ) > $out/loop.log 2>&1
  echo "$label exit=$? end $(date -u +%FT%TZ)" >> $F/chain1.log
  cat $out/loop.log >> $F/chain1.log
}
run new_sm8 $W 5 tests_sm_entry.SM8AtTheRestart
run old_mutA $C/old_mutA 3 tests_sm_entry.SM8AtTheRestart
run new_mutA $C/new_mutA 3 tests_sm_entry.SM8AtTheRestart
run old_mutC $C/old_mutC 3 tests_sm_entry.SM8AtTheRestart
run new_mutC $C/new_mutC 3 tests_sm_entry.SM8AtTheRestart
run old_mutD $C/old_mutD 2 tests_sm_entry.SM8AtTheRestart.test_control_the_same_crash_without_the_change_restarts
run new_mutD $C/new_mutD 2 tests_sm_entry.SM8AtTheRestart.test_control_the_same_crash_without_the_change_restarts
run preslow $C/preslow 3 tests_sm_entry.SM8AtTheRestart
run new_forced $W 3 tests_sm_entry.SM8ForcedInterleaving
echo CHAIN1_DONE >> $F/chain1.log
