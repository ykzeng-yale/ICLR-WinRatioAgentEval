"""Build the superseding SM8 diagnosis receipt and its archives (session work area tool).

usage: build.py --fix-commit SHA [--dry-run]

Writes ONLY new files (write-once): results/live_ab/SM8_DIAGNOSIS_<stamp>.json and
results/live_ab/sm8_diagnosis/<stamp>/{diagnosis_1503_attempts,earlier_runs_logs,
this_step_runs}.tar.gz and MANIFEST.json, in the owner worktree."""
import argparse
import glob
import json
import os
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gather as G                                   # noqa: E402
from archive_lib import make_archive, verify_archive, sha256_file, utc  # noqa: E402

S, W, F, DIAG, REVIEW = G.S, G.W, G.F, G.DIAG, G.REVIEW
FORBIDDEN = ('scratchpad', 'CONTRACT.md', 'understand_')


def rel_members_1503() -> list:
    out = []
    for lab, dd in G.LABEL_DIR.items():
        base = DIAG / dd
        for extra in ['attempts.jsonl'] + [os.path.basename(p) for p in
                                            glob.glob(str(base / 'busy_stopped_*.json'))]:
            out.append(('sm8diag/%s/%s' % (dd, extra), base / extra))
        for a in sorted(glob.glob(str(base / 'attempt_*'))):
            a = Path(a)
            for name in ('stdout.log', 'attempt.json'):
                if (a / name).is_file():
                    out.append(('sm8diag/%s/%s/%s' % (dd, a.name, name), a / name))
            for j in sorted((a / 'trees').glob('*.json')):
                out.append(('sm8diag/%s/%s/trees/%s' % (dd, a.name, j.name), j))
            for t in sorted(p for p in (a / 'trees').iterdir() if p.is_dir()):
                for seg in sorted((t / 'results' / 'T4' / 'events').glob('*.jsonl')):
                    out.append(('sm8diag/%s/%s/trees/%s/results/T4/events/%s'
                                % (dd, a.name, t.name, seg.name), seg))
                ss = t / 'host' / 'shim_state'
                if ss.is_dir():
                    for f in sorted(p for p in ss.iterdir() if p.is_file()):
                        out.append(('sm8diag/%s/%s/trees/%s/host/shim_state/%s'
                                    % (dd, a.name, t.name, f.name), f))
    for log in ('quiescent_loop.log', 'quiescent_loop2.log', 'busy_loop.log', 'fixed_loop.log',
                'fixed_busy_loop.log', 'forced_loop.log', 'CANDIDATES.txt',
                'sm8_attempts_as_run_attempts_1_on.py'):
        out.append(('sm8diag/%s' % log, DIAG / log))
    return out


EARLIER_FILES = [
    'repair/comply/logs/full1_live_ab_controls.log', 'repair/comply/logs/full1_summary.txt',
    'repair/comply/logs/full1_start.txt', 'repair/comply/logs/full2_live_ab_controls.log',
    'repair/comply/logs/full2_summary.txt', 'repair/comply/logs/full2_start.txt',
    'repair/comply/logs/rerun_sm8_1.log', 'repair/comply/logs/rerun_sm8_2.log',
    'repair/comply/logs/rerun_sm8_3.log', 'repair/comply/logs/runs.txt',
    'repair/comply/logs/suites.sh',
    'eb1_1905/run2_controls.log', 'eb1_1905/fix1.log',
    'v3logs/base_controls.log', 'v3logs/after_controls.log', 'v3logs/SUMMARY.txt',
    'final_fix/logs/full_controls1.log', 'final_fix/logs/full_controls1.time',
    'repro_eb1eb5/logs/run15_full_c001354_live_ab_controls.log',
    'repro_eb1eb5/logs/run15_controls.start', 'repro_eb1eb5/logs/run15_controls.end',
    'repro_eb1eb5/logs/run25_wt_live_ab_controls.log', 'repro_eb1eb5/logs/run25_progress.txt',
    'repro_eb1eb5/run25_all.sh',
    'v4/full1/live_ab_controls.log', 'v4/full1/summary.txt',
    'v4/full2/live_ab_controls.log', 'v4/full2/summary.txt', 'v4/suites.sh',
    'v4/sm8_1.log', 'v4/sm8_2.log', 'v4/sm8_3.log',
    'repair/review_tmp/final/logs/combined_live_ab_controls.log',
]


def rel_members_earlier() -> list:
    out = [('work_area/%s' % r, S / r) for r in EARLIER_FILES]
    for tag in ('pre', 'post', 'mutA', 'mutB', 'mutC', 'preslow'):
        out.append(('review_runs/%s/ledger.jsonl' % tag, REVIEW / 'runs' / tag / 'ledger.jsonl'))
    for name in ('chain.sh', 'chain.log', 'chain2.sh', 'chain2.log', 'runner.py',
                 'runs_post.log'):
        out.append(('review_runs/%s' % name, REVIEW / name))
    return out


def rel_members_step() -> list:
    out = []
    for d in sorted((F / 'runs').iterdir()):
        if not d.is_dir():
            continue
        for name in ('tree_state.txt', 'files.sha256', 'loop.log'):
            if (d / name).is_file():
                out.append(('fixsm8/runs/%s/%s' % (d.name, name), d / name))
        loopd = d / 'loop'
        if (loopd / 'attempts.jsonl').is_file():
            out.append(('fixsm8/runs/%s/loop/attempts.jsonl' % d.name, loopd / 'attempts.jsonl'))
        for a in sorted(loopd.glob('attempt_*')):
            for name in ('stdout.log', 'attempt.json'):
                if (a / name).is_file():
                    out.append(('fixsm8/runs/%s/loop/%s/%s' % (d.name, a.name, name), a / name))
            trees = a / 'trees'
            if not trees.is_dir():
                continue
            for j in sorted(trees.glob('*.json')):
                out.append(('fixsm8/runs/%s/loop/%s/trees/%s' % (d.name, a.name, j.name), j))
            for t in sorted(p for p in trees.iterdir() if p.is_dir()):
                for seg in sorted((t / 'results' / 'T4' / 'events').glob('*.jsonl')):
                    out.append(('fixsm8/runs/%s/loop/%s/trees/%s/results/T4/events/%s'
                                % (d.name, a.name, t.name, seg.name), seg))
                ss = t / 'host' / 'shim_state'
                if ss.is_dir():
                    for f in sorted(p for p in ss.iterdir() if p.is_file()):
                        out.append(('fixsm8/runs/%s/loop/%s/trees/%s/host/shim_state/%s'
                                    % (d.name, a.name, t.name, f.name), f))
    for name in ('mutate.py', 'chain1.sh', 'chain1.log', 'chain1b.sh', 'chain3.sh', 'chain3.log',
                 'check_answered.py', 'gather.py', 'archive_lib.py', 'build.py', 'narrative.py',
                 'sm8_attempts_runner_variant.py', 'fix.diff', 'fix_final.diff') + tuple(
                     p.name for p in sorted(F.glob('clones_*.diff'))):
        if (F / name).is_file():
            out.append(('fixsm8/%s' % name, F / name))
    return out


def scan_forbidden(obj) -> list:
    text = json.dumps(obj)
    return [w for w in FORBIDDEN if w in text]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--fix-commit', required=True)
    ap.add_argument('--dry-run', action='store_true')
    args = ap.parse_args()
    import narrative as N
    now = time.time()
    stamp = time.strftime('%Y%m%d_%H%M', time.gmtime(now))
    out_json = W / 'results' / 'live_ab' / ('SM8_DIAGNOSIS_%s.json' % stamp)
    out_dir = W / 'results' / 'live_ab' / 'sm8_diagnosis' / stamp
    rel_dir = 'results/live_ab/sm8_diagnosis/%s' % stamp
    assert not out_json.exists() and not out_dir.exists(), 'write-once'
    facts = {'integrated': G.integrated(), 'solo': G.solo(),
             'old_attempts_check': G.old_attempts_check(),
             'old_forced_loads': G.old_forced_loads(),
             'old_answered_counts': G.old_answered_counts(),
             'review_runs': G.review_runs(), 'step_runs': G.step_runs()}
    archives = {}
    target = F / 'tmp' / ('archives_%s' % stamp) if args.dry_run else out_dir
    for name, members in (('diagnosis_1503_attempts.tar.gz', rel_members_1503()),
                          ('earlier_runs_logs.tar.gz', rel_members_earlier()),
                          ('this_step_runs.tar.gz', rel_members_step())):
        rec = make_archive(target / name, members)
        problems = verify_archive(target / name, rec)
        assert problems == [], problems
        archives[name] = rec
    manifest = {'schema': 'live_ab/sm8_diagnosis_archive_manifest-v1',
                'receipt': 'results/live_ab/SM8_DIAGNOSIS_%s.json' % stamp,
                'archives': {'%s/%s' % (rel_dir, k): {kk: vv for kk, vv in v.items()}
                             for k, v in archives.items()}}
    receipt = N.receipt(stamp=stamp, now=now, fix_commit=args.fix_commit, facts=facts,
                        archives={'%s/%s' % (rel_dir, k): {kk: vv for kk, vv in v.items()
                                                           if kk != 'rows'}
                                  for k, v in archives.items()},
                        manifest_rel='%s/MANIFEST.json' % rel_dir)
    bad = scan_forbidden(receipt) + scan_forbidden(manifest)
    assert not bad, bad
    mtext = json.dumps(manifest, indent=1, sort_keys=True) + '\n'
    (target / 'MANIFEST.json').write_text(mtext, encoding='utf-8')
    receipt['archives_manifest'] = {'path': '%s/MANIFEST.json' % rel_dir,
                                    'sha256': sha256_file(target / 'MANIFEST.json'),
                                    'what': 'every member of the three archives: name, bytes, '
                                            'SHA-256, file mtime'}
    rtext = json.dumps(receipt, indent=1, sort_keys=True) + '\n'
    dest = (F / 'tmp' / out_json.name) if args.dry_run else out_json
    assert not dest.exists()
    dest.write_text(rtext, encoding='utf-8')
    print(json.dumps({'receipt': str(dest), 'bytes': len(rtext.encode()),
                      'archives': {k: (v['bytes'], v['members']) for k, v in archives.items()}},
                     indent=1))
    return 0


if __name__ == '__main__':
    sys.exit(main())
