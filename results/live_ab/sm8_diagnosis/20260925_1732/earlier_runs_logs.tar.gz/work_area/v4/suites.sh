#!/bin/bash
# usage: suites.sh <tag>  -- the five suites one after another, from the worktree root
cd /private/tmp/claude-501/-Users-yukangzengcmac-ICLR-WinRatioAgentEvals/35a3ef1c-e430-45ac-b78e-94ba942c34a1/scratchpad/wt-eb1
PY=/Users/yukangzengcmac/ICLR-WinRatioAgentEvals/.venv/bin/python
L=../v4/$1
mkdir -p $L
echo "head $(git rev-parse HEAD) status: $(git status --short | tr '\n' ';')" > $L/summary.txt
for s in live_ab live_ab_controls live_ab_serving live_ab_tools; do
  st=$(date -u +%FT%TZ)
  $PY -m unittest discover -s experiments/$s -p 'tests_*.py' > $L/$s.log 2>&1
  rc=$?
  echo "$s start=$st end=$(date -u +%FT%TZ) exit=$rc $(grep -E '^Ran ' $L/$s.log | tail -1) $(grep -E '^(OK|FAILED)' $L/$s.log | tail -1) sha=$(shasum -a 256 $L/$s.log | cut -c1-16)" >> $L/summary.txt
done
st=$(date -u +%FT%TZ)
$PY experiments/live_ab_validation/tests_validation.py > $L/validation.log 2>&1
rc=$?
echo "validation start=$st end=$(date -u +%FT%TZ) exit=$rc $(grep -E '^Ran ' $L/validation.log | tail -1) $(grep -E '^(OK|FAILED)' $L/validation.log | tail -1) sha=$(shasum -a 256 $L/validation.log | cut -c1-16)" >> $L/summary.txt
echo DONE >> $L/summary.txt
