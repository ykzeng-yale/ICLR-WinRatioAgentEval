#!/bin/zsh
SP=/private/tmp/claude-501/-Users-yukangzengcmac-ICLR-WinRatioAgentEvals/35a3ef1c-e430-45ac-b78e-94ba942c34a1/scratchpad
R=$SP/repro_eb1eb5; P=/Users/yukangzengcmac/ICLR-WinRatioAgentEvals/.venv/bin/python
cd $SP/wt-eb1
for s in live_ab live_ab_controls live_ab_serving live_ab_tools; do
  echo "$s start $(date -u +%FT%TZ)" >> $R/logs/run25_progress.txt
  /usr/bin/time -p $P -m unittest discover -v -s experiments/$s -p 'tests_*.py' > $R/logs/run25_wt_$s.log 2>&1
  echo "$s exit=$? end $(date -u +%FT%TZ)" >> $R/logs/run25_progress.txt
done
echo "validation start $(date -u +%FT%TZ)" >> $R/logs/run25_progress.txt
/usr/bin/time -p $P experiments/live_ab_validation/tests_validation.py > $R/logs/run25_wt_validation.log 2>&1
echo "validation exit=$? end $(date -u +%FT%TZ)" >> $R/logs/run25_progress.txt
echo DONE >> $R/logs/run25_progress.txt
