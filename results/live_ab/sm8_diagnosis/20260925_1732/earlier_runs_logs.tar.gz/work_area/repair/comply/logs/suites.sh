#!/bin/bash
WT=/private/tmp/claude-501/-Users-yukangzengcmac-ICLR-WinRatioAgentEvals/35a3ef1c-e430-45ac-b78e-94ba942c34a1/scratchpad/wt-eb1
L=/private/tmp/claude-501/-Users-yukangzengcmac-ICLR-WinRatioAgentEvals/35a3ef1c-e430-45ac-b78e-94ba942c34a1/scratchpad/repair/comply/logs
PY=/Users/yukangzengcmac/ICLR-WinRatioAgentEvals/.venv/bin/python
TAG=$1
cd $WT
date -u +%FT%TZ > $L/${TAG}_start.txt
ps -axo pid,etime,command | grep -i "llama-server\|mock_server\|lab_worker" | grep -v grep > $L/${TAG}_host_before.txt
for d in live_ab live_ab_tools live_ab_serving live_ab_controls; do
  start=$(date +%s)
  $PY -m unittest discover -s experiments/$d -p 'tests_*.py' > $L/${TAG}_$d.log 2>&1
  echo "$d rc=$? $(( $(date +%s) - start ))s $(grep -E '^Ran|^OK|^FAILED' $L/${TAG}_$d.log | tr '\n' ' ')" >> $L/${TAG}_summary.txt
done
start=$(date +%s)
$PY experiments/live_ab_validation/tests_validation.py > $L/${TAG}_validation.log 2>&1
echo "validation rc=$? $(( $(date +%s) - start ))s $(tail -3 $L/${TAG}_validation.log | tr '\n' ' ')" >> $L/${TAG}_summary.txt
ps -axo pid,etime,command | grep -i "llama-server\|mock_server\|lab_worker" | grep -v grep > $L/${TAG}_host_after.txt
date -u +%FT%TZ > $L/${TAG}_end.txt
echo DONE >> $L/${TAG}_summary.txt
