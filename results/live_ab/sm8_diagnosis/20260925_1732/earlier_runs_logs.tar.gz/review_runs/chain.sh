#!/bin/zsh
R=/private/tmp/claude-501/-Users-yukangzengcmac-ICLR-WinRatioAgentEvals/35a3ef1c-e430-45ac-b78e-94ba942c34a1/scratchpad/repair/review_tmp/sm8
PY=/Users/yukangzengcmac/ICLR-WinRatioAgentEvals/.venv/bin/python
while pgrep -f "runner.py $R/clone tests_sm_entry.SM8AtTheRestart $R/runs/post" >/dev/null; do sleep 5; done
cd $R
$PY runner.py $R/clone_pre tests_sm_entry.SM8AtTheRestart $R/runs/pre 10 pre preserve
$PY runner.py $R/clone_mutA tests_sm_entry.SM8AtTheRestart $R/runs/mutA 4 mutA_sm8 preserve
$PY runner.py $R/clone_mutA tests_sm_entry.SM8ForcedInterleaving $R/runs/mutA 3 mutA_forced preserve
$PY runner.py $R/clone_mutB tests_sm_entry.SM8AtTheRestart $R/runs/mutB 3 mutB_sm8 preserve
$PY runner.py $R/clone_mutC tests_sm_entry.SM8AtTheRestart $R/runs/mutC 3 mutC_sm8 preserve
$PY runner.py $R/clone_mutC tests_sm_entry.SM8ForcedInterleaving $R/runs/mutC 2 mutC_forced preserve
echo CHAIN_DONE
