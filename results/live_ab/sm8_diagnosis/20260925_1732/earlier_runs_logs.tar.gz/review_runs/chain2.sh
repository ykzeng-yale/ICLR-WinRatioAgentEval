#!/bin/zsh
R=/private/tmp/claude-501/-Users-yukangzengcmac-ICLR-WinRatioAgentEvals/35a3ef1c-e430-45ac-b78e-94ba942c34a1/scratchpad/repair/review_tmp/sm8
PY=/Users/yukangzengcmac/ICLR-WinRatioAgentEvals/.venv/bin/python
while pgrep -f "chain.sh" >/dev/null; do sleep 5; done
cd $R
$PY runner.py $R/clone_preslow tests_sm_entry.SM8AtTheRestart $R/runs/preslow 3 preslow preserve
echo CHAIN2_DONE
