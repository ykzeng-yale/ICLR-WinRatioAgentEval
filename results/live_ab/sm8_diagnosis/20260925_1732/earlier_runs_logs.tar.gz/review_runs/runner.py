"""Reviewer's attempt runner (scratch, not part of the repo).

For each attempt: wait until no foreign harness test process runs (never signals anything),
record loadavg + soft host gate + the list of harness-like processes, then run
`python -m unittest -v <test>` (plain, no wrappers) or `sm8_attempts.py child` (preserving trees)
in <clone>/experiments/live_ab_controls, record rc, duration, stdout, per-test verdicts and
the SM8 failure mode.
"""
import hashlib, json, os, subprocess, sys, time
from pathlib import Path

PY = '/Users/yukangzengcmac/ICLR-WinRatioAgentEvals/.venv/bin/python'
WORDS = ('lab_orchestrator', 'eb1c', 'lab_mock_server', 'unittest', 'lab_worker',
         'sm8_attempts', 'llama-server')


def utc():
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())


def harness_procs():
    me = os.getpid()
    res = subprocess.run(['ps', '-Ao', 'pid=,ppid=,etime=,pcpu=,command='],
                         capture_output=True, text=True)
    rows = []
    for line in res.stdout.splitlines():
        p = line.split(None, 4)
        if len(p) < 5:
            continue
        if int(p[0]) == me or int(p[1]) == me:
            continue
        if 'runner.py' in p[4] or ' ps -Ao' in p[4]:
            continue
        if any(w in p[4] for w in WORDS):
            rows.append({'pid': int(p[0]), 'etime': p[2], 'pcpu': p[3], 'cmd': p[4][:200]})
    return rows


def gate(clone):
    code = ('import sys,json,os;sys.path.insert(0,%r);import lab_hostcheck as h;'
            's=h.soft_host_check({os.getpid()});'
            'print(json.dumps({"clean":s.clean,"baseline_active":bool(s.baseline_active),'
            '"degraded":list(s.degraded),"n_findings":len(s.findings),'
            '"detectors":sorted({str(f.get("detector")) for f in s.findings})}))'
            % str(Path(clone) / 'experiments' / 'live_ab'))
    res = subprocess.run([PY, '-c', code], capture_output=True, text=True, timeout=120)
    try:
        return json.loads(res.stdout.strip().splitlines()[-1])
    except Exception:
        return {'error': res.stderr[-500:]}


def verdicts(out):
    v = {}
    for ln in out.splitlines():
        if ln.startswith('test') and ' ... ' in ln:
            v[ln.split(' ', 1)[0]] = ln.rsplit(' ... ', 1)[1].strip()
    return v


def mode(out, name='test_sm8_a_library_changed_before_the_restart_refuses_it'):
    v = verdicts(out).get(name)
    if v in (None, 'ok'):
        return v or 'not_run'
    blocks = out.split('=' * 70)
    b = next((b for b in blocks if ('FAIL: %s ' % name) in b or ('ERROR: %s ' % name) in b), '')
    if 'host_not_quiescent' in b:
        return 'host_not_quiescent'
    if 'AssertionError: 0 != 1' in b:
        return 'exit_0_not_1'
    return 'other'


def main():
    clone, test, outdir, n, tag = sys.argv[1], sys.argv[2], Path(sys.argv[3]), int(sys.argv[4]), sys.argv[5]
    preserve = len(sys.argv) > 6 and sys.argv[6] == 'preserve'
    outdir.mkdir(parents=True, exist_ok=True)
    cwd = Path(clone) / 'experiments' / 'live_ab_controls'
    for k in range(1, n + 1):
        waited = 0
        while harness_procs() and waited < 900:
            time.sleep(10)
            waited += 10
        gwait = 0
        while not gate(clone).get('clean') and gwait < 600:
            time.sleep(10)
            gwait += 10
        rec = {'tag': tag, 'k': k, 'clone': clone, 'test': test,
               'head': subprocess.run(['git', '-C', clone, 'rev-parse', 'HEAD'],
                                      capture_output=True, text=True).stdout.strip(),
               'waited_for_quiet_s': waited, 'harness_procs_before': harness_procs(),
               'loadavg_before': os.getloadavg(), 'gate_before': gate(clone),
               'start_utc': utc()}
        adir = outdir / ('%s_%02d' % (tag, k))
        if preserve:
            cmd = [PY, 'sm8_attempts.py', 'child', '--out', str(adir), '--test', test]
        else:
            cmd = [PY, '-m', 'unittest', '-v', test]
        t0 = time.monotonic()
        res = subprocess.run(cmd, cwd=str(cwd), capture_output=True, text=True, timeout=1800)
        rec['seconds'] = round(time.monotonic() - t0, 3)
        rec['end_utc'] = utc()
        rec['rc'] = res.returncode
        out = res.stdout + res.stderr
        adir.mkdir(parents=True, exist_ok=True)
        (adir / 'stdout.log').write_text(out)
        rec['stdout_sha256'] = hashlib.sha256(out.encode()).hexdigest()
        rec['verdicts'] = verdicts(out)
        rec['sm8_mode'] = mode(out)
        rec['ran_line'] = next((l for l in out.splitlines() if l.startswith('Ran ')), None)
        rec['loadavg_after'] = os.getloadavg()
        with open(outdir / 'ledger.jsonl', 'a') as fh:
            fh.write(json.dumps(rec, sort_keys=True) + '\n')
        print(tag, k, rec['rc'], rec['seconds'], rec['verdicts'], rec['sm8_mode'],
              rec['gate_before'].get('clean'), round(rec['loadavg_before'][0], 2), flush=True)


if __name__ == '__main__':
    main()
