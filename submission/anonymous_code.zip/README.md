# Anonymous supplementary materials

Start with REPRODUCIBILITY.md. Run `python reproduce.py` to check retained results, use its explicit simulation/full options for original studies, or add `--extensions` for the accepted CPU-only all-pairs and drift studies. No commercial API calls occur through this entrypoint. Historical commercial collection scripts are retained for provenance only and are not authorized for execution. New experimental inference is restricted to open-weight/open-source systems.

The paper is paper/manuscript.pdf; complete LaTeX sources, numerical results, protocols, proof appendices and provenance are included. Anonymous manifest copies and their source hashes are documented in results/anonymous_provenance_map.json. The code archive does not assert human scientific signoff or production deployment validation.
