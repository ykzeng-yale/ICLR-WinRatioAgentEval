# Anonymous supplementary materials

Start with REPRODUCIBILITY.md. Run `python reproduce.py` to check the supplied baseline, or use its explicit simulation/full options to regenerate numerical studies. No commercial API calls occur through that entrypoint. Optional prospective runners are supplied for transparency and require separately provided credentials and expenditure authorization.

The paper is paper/manuscript.pdf; complete LaTeX sources, numerical results, protocols, proof appendices and provenance are included. The code archive does not assert human scientific signoff or production deployment validation.
