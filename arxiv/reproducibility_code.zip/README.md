# Guarded Win Statistics: reproducibility supplement

Author: Yukang Zeng. Start with REPRODUCIBILITY.md and `python reproduce.py`.
`python reproduce.py --coding --airline` reconstructs the open-weight summaries
from archived metric projections without running any model or candidate code.
`python reproduce.py --build-pdf` rebuilds the named preprint in paper/.

The full paper is paper/manuscript.pdf; it includes all proof and result
appendices. The historical anonymous-provenance map remains because it records
privacy-preserving transformations of immutable contributed observations.
Legacy ICLR/review references in historical protocols describe their collection
history, not a conference submission or acceptance for this preprint.

No new commercial/proprietary experimental agents, simulators, judges or
fallbacks are authorized. Historical commercial collection scripts are evidence
of past collection only and must not be rerun. Default reproduction verifies
saved results; optional simulation commands are explicitly documented.
The accepted U-statistic runner uses the same scenario values/order and gate
thresholds without importing the excluded generic wincs module. The release-only
dependency repair is recorded in arxiv_source_provenance.json.

This release does not claim human scientific signoff, arXiv submission,
endorsement, moderation acceptance or production validation. Future-study
issues are separate from the evidence included in this first preprint.
